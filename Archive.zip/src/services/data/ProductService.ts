import { EventEmittingService } from '../core/BaseService';
import { getAllProducts, findBestMatchingProduct } from '../product-matcher';
import type {
  Product,
  ProductConfiguration,
  ProductLine,
  ServiceResult,
  RuleOverrides
} from '../types/ServiceTypes';

export interface ProductMatchCriteria {
  sku?: string;
  productLineId?: number;
  mirrorStyleId?: number;
  mirrorStyleCode?: number;
  lightDirectionId?: number;
  configuration?: ProductConfiguration;
  ruleOverrides?: RuleOverrides;
}

export interface ProductSearchOptions {
  productLine?: ProductLine;
  includeInactive?: boolean;
  sortBy?: 'name' | 'sku' | 'relevance';
  limit?: number;
}

export interface ProductMatchResult {
  product: Product | null;
  confidence: number;
  matchedFields: string[];
  fallbackUsed: boolean;
  searchCriteria: ProductMatchCriteria;
}

export class ProductService extends EventEmittingService {
  private allProducts: Product[] = [];
  private productsByLine = new Map<number, Product[]>();
  private isInitialized = false;

  constructor() {
    super();
    this.log('ProductService initialized');
  }

  // Initialization
  public async initialize(): Promise<ServiceResult<Product[]>> {
    if (this.isInitialized) {
      return { success: true, data: this.allProducts };
    }

    return this.withCaching('all-products', async () => {
      try {
        this.log('Loading all products from API');
        const products = await getAllProducts();
        
        this.allProducts = products;
        this.buildProductIndex();
        this.isInitialized = true;
        
        this.log(`Loaded ${products.length} products`);
        this.emit('products-loaded', { products });
        
        return { success: true, data: products };
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Failed to load products';
        this.error('Failed to initialize product service', error);
        return { success: false, error: errorMessage };
      }
    });
  }

  private buildProductIndex(): void {
    this.productsByLine.clear();
    
    this.allProducts.forEach(product => {
      if (!this.productsByLine.has(product.product_line)) {
        this.productsByLine.set(product.product_line, []);
      }
      this.productsByLine.get(product.product_line)!.push(product);
    });

    // Sort products within each line by image availability for better fallback
    this.productsByLine.forEach(products => {
      products.sort((a, b) => {
        const scoreA = this.getImageAvailabilityScore(a);
        const scoreB = this.getImageAvailabilityScore(b);
        return scoreB - scoreA; // Higher score first
      });
    });
  }

  private getImageAvailabilityScore(product: Product): number {
    let score = 0;
    if (product.vertical_image) score += 3;
    if (product.horizontal_image) score += 3;
    if (Array.isArray(product.additional_images) && product.additional_images.length > 0) score += 1;
    return score;
  }

  // Product matching
  public async findProduct(criteria: ProductMatchCriteria): Promise<ServiceResult<ProductMatchResult>> {
    if (!this.isInitialized) {
      const initResult = await this.initialize();
      if (!initResult.success) {
        return { success: false, error: initResult.error };
      }
    }

    try {
      this.log('Finding product with criteria', criteria);

      // Use existing product matcher for backward compatibility
      let product: Product | null = null;
      let confidence = 0;
      let matchedFields: string[] = [];
      let fallbackUsed = false;

      if (criteria.sku) {
        const matchResult = await findBestMatchingProduct({
          sku: criteria.sku,
          productLineId: criteria.productLineId,
          mirrorStyleId: criteria.mirrorStyleId,
          mirrorStyleCode: criteria.mirrorStyleCode,
          lightDirectionId: criteria.lightDirectionId
        });
        
        product = matchResult;
        if (product) {
          confidence = this.calculateConfidence(criteria, product);
          matchedFields = this.getMatchedFields(criteria, product);
        }
      }

      // Fallback strategy if no product found
      if (!product && criteria.productLineId) {
        product = await this.findFallbackProduct(criteria.productLineId);
        fallbackUsed = !!product;
        confidence = fallbackUsed ? 0.3 : 0; // Low confidence for fallback
      }

      const result: ProductMatchResult = {
        product,
        confidence,
        matchedFields,
        fallbackUsed,
        searchCriteria: criteria
      };

      this.emit('product-matched', result);
      
      return { success: true, data: result };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to find product';
      this.error('Failed to find product', error);
      return { success: false, error: errorMessage };
    }
  }

  private async findFallbackProduct(productLineId: number): Promise<Product | null> {
    const productsForLine = this.productsByLine.get(productLineId) || [];
    
    if (productsForLine.length === 0) {
      return null;
    }

    // Return the product with the highest image availability score
    return productsForLine[0];
  }

  private calculateConfidence(criteria: ProductMatchCriteria, product: Product): number {
    let matches = 0;
    let total = 0;

    // Check SKU match
    if (criteria.sku) {
      total++;
      if (product.sku_code && criteria.sku.toUpperCase().includes(product.sku_code.toUpperCase())) {
        matches++;
      }
    }

    // Check product line match
    if (criteria.productLineId) {
      total++;
      if (product.product_line === criteria.productLineId) {
        matches++;
      }
    }

    // Check mirror style match
    if (criteria.mirrorStyleId || criteria.mirrorStyleCode) {
      total++;
      if ((criteria.mirrorStyleId && product.mirror_style === criteria.mirrorStyleId) ||
          (criteria.mirrorStyleCode && product.mirror_style === criteria.mirrorStyleCode)) {
        matches++;
      }
    }

    // Check light direction match
    if (criteria.lightDirectionId) {
      total++;
      if (product.light_direction === criteria.lightDirectionId) {
        matches++;
      }
    }

    return total > 0 ? matches / total : 0;
  }

  private getMatchedFields(criteria: ProductMatchCriteria, product: Product): string[] {
    const matched: string[] = [];

    if (criteria.sku && product.sku_code && criteria.sku.toUpperCase().includes(product.sku_code.toUpperCase())) {
      matched.push('sku');
    }
    if (criteria.productLineId && product.product_line === criteria.productLineId) {
      matched.push('product_line');
    }
    if (criteria.mirrorStyleId && product.mirror_style === criteria.mirrorStyleId) {
      matched.push('mirror_style');
    }
    if (criteria.lightDirectionId && product.light_direction === criteria.lightDirectionId) {
      matched.push('light_direction');
    }

    return matched;
  }

  // Product search and filtering
  public async searchProducts(
    query: string, 
    options: ProductSearchOptions = {}
  ): Promise<ServiceResult<Product[]>> {
    if (!this.isInitialized) {
      const initResult = await this.initialize();
      if (!initResult.success) {
        return { success: false, error: initResult.error };
      }
    }

    try {
      let products = [...this.allProducts];

      // Filter by product line
      if (options.productLine) {
        products = products.filter(p => p.product_line === options.productLine!.id);
      }

      // Filter by active status
      if (!options.includeInactive) {
        products = products.filter(p => p.active !== false);
      }

      // Apply search query
      if (query.trim()) {
        const queryUpper = query.toUpperCase();
        products = products.filter(product => 
          (product.name || '').toUpperCase().includes(queryUpper) ||
          (product.sku_code || '').toUpperCase().includes(queryUpper)
        );
      }

      // Sort results
      switch (options.sortBy) {
        case 'name':
          products.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
          break;
        case 'sku':
          products.sort((a, b) => (a.sku_code || '').localeCompare(b.sku_code || ''));
          break;
        case 'relevance':
        default:
          // Sort by image availability score for relevance
          products.sort((a, b) => this.getImageAvailabilityScore(b) - this.getImageAvailabilityScore(a));
          break;
      }

      // Apply limit
      if (options.limit && options.limit > 0) {
        products = products.slice(0, options.limit);
      }

      return { success: true, data: products };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to search products';
      this.error('Failed to search products', error);
      return { success: false, error: errorMessage };
    }
  }

  public getProductsByLine(productLineId: number): Product[] {
    if (!this.isInitialized) {
      return [];
    }
    return [...(this.productsByLine.get(productLineId) || [])];
  }

  public getProductById(id: number): Product | null {
    if (!this.isInitialized) {
      return null;
    }
    return this.allProducts.find(p => p.id === id) || null;
  }

  public getProductBySkuCode(skuCode: string): Product | null {
    if (!this.isInitialized) {
      return null;
    }
    return this.allProducts.find(p => 
      (p.sku_code || '').toUpperCase() === skuCode.toUpperCase()
    ) || null;
  }

  // Product suggestions for search
  public async getProductSuggestions(
    query: string,
    productLine?: ProductLine,
    limit: number = 10
  ): Promise<ServiceResult<Array<{product: Product; relevance: number}>>> {
    const searchResult = await this.searchProducts(query, { 
      productLine, 
      limit: limit * 2 // Get more results to calculate relevance
    });

    if (!searchResult.success) {
      return { success: false, error: searchResult.error };
    }

    const queryUpper = query.toUpperCase();
    const suggestions = searchResult.data!.map(product => {
      let relevance = 0;
      
      // Exact SKU match gets highest relevance
      if ((product.sku_code || '').toUpperCase() === queryUpper) {
        relevance += 100;
      } else if ((product.sku_code || '').toUpperCase().startsWith(queryUpper)) {
        relevance += 80;
      } else if ((product.sku_code || '').toUpperCase().includes(queryUpper)) {
        relevance += 40;
      }

      // Name matching
      if ((product.name || '').toUpperCase().includes(queryUpper)) {
        relevance += 20;
      }

      // Boost for better image availability
      relevance += this.getImageAvailabilityScore(product);

      return { product, relevance };
    });

    suggestions.sort((a, b) => b.relevance - a.relevance);
    
    return { 
      success: true, 
      data: suggestions.slice(0, limit) 
    };
  }

  // Cache and refresh
  public async refreshProducts(): Promise<ServiceResult<Product[]>> {
    this.clearCache('all-products');
    this.isInitialized = false;
    return this.initialize();
  }

  public getAllProducts(): Product[] {
    return [...this.allProducts];
  }

  public getProductStats(): {
    total: number;
    byLine: Record<number, number>;
    withImages: number;
  } {
    const byLine: Record<number, number> = {};
    let withImages = 0;

    this.allProducts.forEach(product => {
      byLine[product.product_line] = (byLine[product.product_line] || 0) + 1;
      
      if (product.vertical_image || product.horizontal_image || 
          (Array.isArray(product.additional_images) && product.additional_images.length > 0)) {
        withImages++;
      }
    });

    return {
      total: this.allProducts.length,
      byLine,
      withImages
    };
  }
}