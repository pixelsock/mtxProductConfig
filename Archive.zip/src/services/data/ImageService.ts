import { EventEmittingService } from '../core/BaseService';
import { selectProductImage, constructDirectusAssetUrl } from '../image-selector';
import type {
  Product,
  ProductConfiguration,
  ServiceResult,
  ImageSelection,
  ImageSelectionCriteria,
  RuleOverrides
} from '../types/ServiceTypes';

export interface ImageDisplayOptions {
  preferredOrientation?: 'portrait' | 'landscape' | 'auto';
  includeAdditional?: boolean;
  fallbackEnabled?: boolean;
  maxThumbnails?: number;
}

export interface ImageSet {
  primary?: string;
  thumbnails: string[];
  metadata: {
    source: 'vertical' | 'horizontal' | 'additional' | 'fallback';
    orientation: 'portrait' | 'landscape';
    hasRuleOverrides: boolean;
    totalImages: number;
  };
}

export interface ImageLoadResult {
  url: string;
  loaded: boolean;
  error?: string;
  dimensions?: { width: number; height: number };
}

export class ImageService extends EventEmittingService {
  private imageCache = new Map<string, ImageLoadResult>();
  private loadingPromises = new Map<string, Promise<ImageLoadResult>>();

  constructor() {
    super();
    this.log('ImageService initialized');
  }

  // Primary image selection
  public selectProductImages(
    product: Product | null,
    configuration?: ProductConfiguration,
    ruleOverrides?: RuleOverrides,
    options: ImageDisplayOptions = {}
  ): ServiceResult<ImageSet> {
    if (!product) {
      return {
        success: false,
        error: 'No product provided',
        data: this.getEmptyImageSet()
      };
    }

    try {
      // Build selection criteria
      const criteria: ImageSelectionCriteria = {
        product,
        configuration,
        ruleOverrides
      };

      // Use existing image selector for backward compatibility
      const imageSelection = selectProductImage(
        product, 
        this.getMountingOptionFromConfig(configuration),
        ruleOverrides
      );

      // Build thumbnail list
      const thumbnails = this.buildThumbnailList(product, {
        includeAdditional: options.includeAdditional !== false,
        maxThumbnails: options.maxThumbnails || 10
      });

      const imageSet: ImageSet = {
        primary: imageSelection.primaryImage || undefined,
        thumbnails,
        metadata: {
          source: imageSelection.source,
          orientation: imageSelection.orientation,
          hasRuleOverrides: !!ruleOverrides && Object.keys(ruleOverrides).length > 0,
          totalImages: this.getTotalImageCount(product)
        }
      };

      this.emit('images-selected', { product, imageSet, criteria });

      return { success: true, data: imageSet };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to select product images';
      this.error('Failed to select product images', error);
      
      return {
        success: false,
        error: errorMessage,
        data: this.getEmptyImageSet()
      };
    }
  }

  private getMountingOptionFromConfig(configuration?: ProductConfiguration): any {
    if (!configuration?.mounting) {
      return undefined;
    }

    // This would normally come from the ProductLineService
    // For now, create a simple mounting option object
    return {
      id: parseInt(configuration.mounting),
      name: configuration.mounting.includes('portrait') ? 'Portrait' : 'Landscape'
    };
  }

  // Thumbnail management
  private buildThumbnailList(
    product: Product,
    options: { includeAdditional: boolean; maxThumbnails: number }
  ): string[] {
    const urls: string[] = [];
    const seen = new Set<string>();

    const addUnique = (url?: string) => {
      if (url && !seen.has(url)) {
        seen.add(url);
        urls.push(url);
      }
    };

    // Add additional images (excluding primary images to avoid duplicates)
    if (options.includeAdditional && Array.isArray(product.additional_images)) {
      for (const item of product.additional_images) {
        let id: string | undefined;
        
        if (typeof item === 'number' || typeof item === 'string') {
          id = String(item);
        } else if (item && typeof item === 'object') {
          const file = (item as any).directus_files_id;
          id = typeof file === 'string' ? file : file?.id;
        }
        
        if (id) {
          addUnique(constructDirectusAssetUrl(id));
        }
      }
    }

    // Limit thumbnails
    return urls.slice(0, options.maxThumbnails);
  }

  private getTotalImageCount(product: Product): number {
    let count = 0;
    if (product.vertical_image) count++;
    if (product.horizontal_image) count++;
    if (Array.isArray(product.additional_images)) count += product.additional_images.length;
    return count;
  }

  // Image loading and caching
  public async preloadImage(url: string): Promise<ServiceResult<ImageLoadResult>> {
    // Check cache first
    const cached = this.imageCache.get(url);
    if (cached) {
      return { success: true, data: cached, cached: true };
    }

    // Check if already loading
    const existingPromise = this.loadingPromises.get(url);
    if (existingPromise) {
      try {
        const result = await existingPromise;
        return { success: true, data: result };
      } catch (error) {
        return { success: false, error: error instanceof Error ? error.message : 'Failed to load image' };
      }
    }

    // Start loading
    const loadPromise = this.loadImageWithMetadata(url);
    this.loadingPromises.set(url, loadPromise);

    try {
      const result = await loadPromise;
      this.imageCache.set(url, result);
      this.loadingPromises.delete(url);
      
      this.emit('image-loaded', { url, result });
      
      return { success: true, data: result };
    } catch (error) {
      this.loadingPromises.delete(url);
      const errorMessage = error instanceof Error ? error.message : 'Failed to load image';
      this.error(`Failed to preload image: ${url}`, error);
      
      return { success: false, error: errorMessage };
    }
  }

  private async loadImageWithMetadata(url: string): Promise<ImageLoadResult> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const startTime = Date.now();

      img.onload = () => {
        const loadTime = Date.now() - startTime;
        this.log(`Image loaded in ${loadTime}ms: ${url}`);
        
        resolve({
          url,
          loaded: true,
          dimensions: {
            width: img.naturalWidth,
            height: img.naturalHeight
          }
        });
      };

      img.onerror = () => {
        const error = `Failed to load image: ${url}`;
        resolve({
          url,
          loaded: false,
          error
        });
      };

      // Set timeout for loading
      setTimeout(() => {
        if (!img.complete) {
          resolve({
            url,
            loaded: false,
            error: 'Image load timeout'
          });
        }
      }, 10000); // 10 second timeout

      img.src = url;
    });
  }

  // Batch operations
  public async preloadImageSet(imageSet: ImageSet): Promise<ServiceResult<Record<string, ImageLoadResult>>> {
    const urls = [imageSet.primary, ...imageSet.thumbnails].filter(Boolean) as string[];
    const results: Record<string, ImageLoadResult> = {};
    const errors: string[] = [];

    // Load all images in parallel
    const loadPromises = urls.map(async (url) => {
      const result = await this.preloadImage(url);
      if (result.success) {
        results[url] = result.data!;
      } else {
        errors.push(`${url}: ${result.error}`);
      }
      return result;
    });

    await Promise.all(loadPromises);

    this.emit('imageset-preloaded', { imageSet, results, errors });

    return {
      success: errors.length === 0,
      data: results,
      error: errors.length > 0 ? errors.join('; ') : undefined
    };
  }

  // Image optimization and transformation
  public getOptimizedImageUrl(
    url: string,
    options: {
      width?: number;
      height?: number;
      quality?: number;
      format?: 'webp' | 'jpg' | 'png';
    } = {}
  ): string {
    if (!url.includes('pim.dude.digital')) {
      return url; // Don't modify external URLs
    }

    const params = new URLSearchParams();
    
    if (options.width) params.set('width', options.width.toString());
    if (options.height) params.set('height', options.height.toString());
    if (options.quality) params.set('quality', options.quality.toString());
    if (options.format) params.set('format', options.format);

    if (params.toString()) {
      return `${url}?${params.toString()}`;
    }

    return url;
  }

  // Utility methods
  private getEmptyImageSet(): ImageSet {
    return {
      thumbnails: [],
      metadata: {
        source: 'fallback',
        orientation: 'landscape',
        hasRuleOverrides: false,
        totalImages: 0
      }
    };
  }

  public buildFallbackImageUrl(productName?: string): string {
    const fallbackText = encodeURIComponent(productName || 'Product');
    return `https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=800&h=600&q=80&text=${fallbackText}`;
  }

  public getImageDimensions(url: string): { width: number; height: number } | null {
    const cached = this.imageCache.get(url);
    return cached?.dimensions || null;
  }

  public getImageLoadStatus(url: string): 'loading' | 'loaded' | 'error' | 'not-started' {
    if (this.loadingPromises.has(url)) {
      return 'loading';
    }
    
    const cached = this.imageCache.get(url);
    if (cached) {
      return cached.loaded ? 'loaded' : 'error';
    }
    
    return 'not-started';
  }

  // Cache management
  public clearImageCache(): void {
    this.imageCache.clear();
    this.loadingPromises.clear();
    this.emit('cache-cleared', {});
  }

  public getCacheStats(): {
    totalCached: number;
    loadedCount: number;
    errorCount: number;
    cacheSize: string;
  } {
    const totalCached = this.imageCache.size;
    let loadedCount = 0;
    let errorCount = 0;

    this.imageCache.forEach(result => {
      if (result.loaded) {
        loadedCount++;
      } else {
        errorCount++;
      }
    });

    // Rough estimate of cache size
    const avgUrlLength = 100;
    const avgResultSize = 200;
    const estimatedSize = this.imageCache.size * (avgUrlLength + avgResultSize);
    const cacheSize = estimatedSize > 1024 * 1024 
      ? `${(estimatedSize / (1024 * 1024)).toFixed(1)}MB`
      : `${(estimatedSize / 1024).toFixed(1)}KB`;

    return {
      totalCached,
      loadedCount,
      errorCount,
      cacheSize
    };
  }

  // Advanced image operations
  public async analyzeImageSet(imageSet: ImageSet): Promise<ServiceResult<{
    aspectRatios: Record<string, number>;
    averageQuality: number;
    recommendations: string[];
  }>> {
    const analysis = {
      aspectRatios: {} as Record<string, number>,
      averageQuality: 0,
      recommendations: [] as string[]
    };

    const allUrls = [imageSet.primary, ...imageSet.thumbnails].filter(Boolean) as string[];
    let qualitySum = 0;
    let qualityCount = 0;

    for (const url of allUrls) {
      const dimensions = this.getImageDimensions(url);
      if (dimensions) {
        const aspectRatio = dimensions.width / dimensions.height;
        analysis.aspectRatios[url] = aspectRatio;
        
        // Simple quality estimate based on dimensions
        const pixelCount = dimensions.width * dimensions.height;
        const quality = Math.min(100, Math.max(20, (pixelCount / 10000) * 10));
        qualitySum += quality;
        qualityCount++;
      }
    }

    if (qualityCount > 0) {
      analysis.averageQuality = qualitySum / qualityCount;
    }

    // Generate recommendations
    if (analysis.averageQuality < 50) {
      analysis.recommendations.push('Consider using higher resolution images for better quality');
    }
    
    if (Object.keys(analysis.aspectRatios).length > 0) {
      const ratios = Object.values(analysis.aspectRatios);
      const avgRatio = ratios.reduce((a, b) => a + b, 0) / ratios.length;
      
      if (avgRatio > 1.5) {
        analysis.recommendations.push('Images are very wide - consider using more square formats');
      } else if (avgRatio < 0.7) {
        analysis.recommendations.push('Images are very tall - consider using more square formats');
      }
    }

    if (imageSet.thumbnails.length === 0) {
      analysis.recommendations.push('No additional images available - consider adding more product photos');
    }

    return { success: true, data: analysis };
  }
}